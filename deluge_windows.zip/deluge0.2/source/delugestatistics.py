#!/usr/bin env python

class Statistics(self):
    pass
